<?php

session_unset();
echo'<script>
location.reload();
</script>
';
?>