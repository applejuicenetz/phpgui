<?php
session_start();
require_once "_classes/subs.php";
require_once "_classes/core.php";
require_once "_classes/share.php";

$core = new Core();
$share = new Share();

echo '<style type="text/css">
select {width:100%;}
</style>';

echo "<script>
function ShowFiles(dir){
	dir=encodeURIComponent(dir);
	var sharelist=window.open('index.php?site=sharefiles&dir='+dir+'&".SID."','ajsharelist',
		'width=720,height=500,left=10,top=10,dependent=yes,scrollbars=yes');
}

function do_setsubs(name, newsub){
	name=encodeURIComponent(name);
	window.location.href='".$_SERVER['PHP_SELF']."?site=shares&setsubs='+name+'&newsub='+newsub;
}

function delshare(name){
	name=encodeURIComponent(name);
	window.location.href='".$_SERVER['PHP_SELF']."?".SID."&share_del='+name;
}

function newshare(){
	var name=encodeURIComponent(document.mainform.new_share.value);
	var subs=document.mainform.new_subs.checked ? 1 : 0;
	window.location.href='".$_SERVER['PHP_SELF']."index.php?site=shares&new_share='+name+'&new_subs='+subs;
}

function share_export(){
    window.location.href = 'index.php?site=shareexport';
}

function select_dir(){
	var dirlist=window.open(
		'directory.php?returninput=mainform.new_share.value&amp;".SID."',
		'Dirlist','width=400,height=350,left=10,top=10,dependent=yes,scrollbars=no');
	dirlist.focus();
}
</script>
</head>
<body>";

//einstellungen fuer unterverzeichnis aendern
if(!empty($_GET['setsubs'])){
	$share->changesub($_GET['setsubs'], $_GET['newsub']);
}

//verzeichnis aus share nehmen
if(!empty($_GET['share_del'])){
	$share->del_share($_GET['share_del']);
}

//verzeichnis sharen
if(!empty($_GET['new_share'])){
	$share->add_share($_GET['new_share'], $_GET['new_subs']);
	$message("Shareverzichnisse werden neu eingelesen und an den Server weitergeleitet.");
}

echo "<form action=\"\" name=\"mainform\">";
echo'<div class="card">
            <div class="card-body">
              <h5 class="card-title">'.$_SESSION["language"]["SHARE"]["SHARED_DIRS"].'</h5>

              <!-- List group with Advanced Contents -->
              <div class="list-group">
                ';
//auch temp-verzeichnis anzeigen (für dateien die gerade geladen werden)
echo'                <a href="index.php?site=sharefiles&dir='.addslashes(htmlspecialchars($share->get_temp())).'" class="list-group-item list-group-item-action" aria-current="true">
                  <div class="d-flex w-100 justify-content-between">
                    <p class="mb-1"><i class="bi bi-folder-symlink"></i> '.htmlspecialchars($share->get_temp()).'</p>
                  <small></small>
                  </div>
                 </a>
';
$sharedirs=$share->get_shared_dirs(1);

//freigegebene verzeichnisse anzeigen
foreach($sharedirs as $a){
	$cur_share=$share->get_shared_dir($a);
	//verzeichnisname -> link zu den einzelnen dateien
	echo'       <a href="index.php?site=sharefiles&dir='.addslashes(htmlspecialchars($cur_share["NAME"])).'" class="list-group-item list-group-item-action" aria-current="true">
                  <div class="d-flex w-100 justify-content-between">
                    <p class="mb-1"><i class="bi bi-folder"></i> '.htmlspecialchars($cur_share["NAME"]).'</p>
                  <small></small>
                  </div>
                 </a>
';
}
echo'</div><!-- End List group Advanced Content -->

            </div>
          </div>';
//Neues verzeichnis freigeben
//echo "\n<tr><td>".$_SESSION['language']['SHARE']['NEW']
//	.": <input name=\"new_share\" size=\"60\" />";
//echo " <input type=\"button\" value=\"...\" onclick=\"select_dir();\" /></td>";
//echo "<td><input type=\"checkbox\" name=\"new_subs\" value=\"1\" "
//	."checked=\"checked\" /></td><td><input type=\"button\" value=\""
//	.$_SESSION['language']['SHARE']['ADD']."\" "
//	."onclick=\"newshare()\"/></td></tr>\n";
//echo "</table>";
//
//echo "<br />\n";
echo "<div align=\"center\"><table><tr>\n";
echo "<td><input type=\"button\" onclick=\"do_setsubs('*sharecheck',0);\" value='"
	.$_SESSION['language']['SHARE']['SHARECHECK']."' /></td>";
//echo "<td><input type=\"button\" onclick=\"share_export()\" value='"
//	.$_SESSION['language']['SHARE']['EXPORTLIST']."' /></td>\n";
echo "</tr></table></div>\n";
echo "</form>\n";

echo "</body>
</html>";
