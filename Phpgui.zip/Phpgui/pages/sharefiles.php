<?php
session_start();
require_once "_classes/subs.php";
require_once "_classes/share.php";
$lang = $_SESSION['language']['SHARE'];
$queryString = strstr($_SERVER['REQUEST_URI'], '?');    // $queryString enth�lt jetzt "?arg1=foo&arg2=bar" oder (bool)false falls keine Parameter definiert wurden
$queryString = ($queryString===false) ? '' : substr($queryString, 1);
 
$Share = new Share();

$Sharelist = $Share;

if(!empty($_GET['clear_list'])){
	$_SESSION['shareexport']=array();
	echo'<div class="alert alert-success alert-dismissible fade show" role="alert">
                Link Export erfolgreich geleert!
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
';
}

if (!empty($_GET['shareexpfile'])) {
    $_SESSION['shareexport'] = [];
    foreach ($_GET['shareexpfile'] as $expid) {
        $shareentry = $Sharelist->get_file($expid);
        $export_currlink = $shareentry['LINK'];
        $testx = array_search($export_currlink, $_SESSION['shareexport']);
        if ($testx !== FALSE) continue;
        $_SESSION['shareexport'][] = $export_currlink;
    }
    require_once "classes/class_core.php";
$core = new Core;


if(empty($_GET['exp_format'])) $_GET['exp_format']="Default";

echo "<form name=\"exportform\" action=\"\">";
if(!empty($_GET['withsource']) && $_GET['withsource']=="true"){}

echo '<div class="card">
            <div class="card-body">
              <h5 class="card-title">Link Export</h5>
';
if(!empty($_SESSION['shareexport'])){
	asort($_SESSION['shareexport']);
	
	foreach($_SESSION['shareexport'] as $a){
		$share_ex = explode('/',$a);
		$share_ex = explode('|',$share_ex[2]);
		$share_ex_link = $a;
		if(!empty($_GET['withsource']) && $_GET['withsource']=="true"){
			$share_ex_link=substr($share_ex_link,0,strlen($share_ex_link)-1)."|"
				.$curr_coreip.":".$_SESSION['phpaj']['core_source_port']
				.$curr_serverip.$curr_serverport."/";
		}
		$share_ex_name = $share_ex[1];
		$share_ex_hash = $share_ex[2];
		$share_ex_bytesize = $share_ex[3];
		$share_ex_size = sizeformat($share_ex[3]);
			}
		
		for($i = 0, $anzahl = count($_SESSION['shareexport']); $i < $anzahl; ++$i) {
			echo $_SESSION['shareexport'][$i]."<br>";
		}
	
}
echo "</div></div>";
echo "<input type=\"button\" value=\""
	.$_SESSION['language']['SHARE']['DEL_EXPORT']
	."\" onclick=\"document.location.href='index.php?site=sharefiles&dir=".$_GET["dir"]."&clear_list=1&"
	.SID."';\" />";
echo "</form>";

}

echo "\n<script>
share_ids = [];

function change(id){
	var share_zeile=document.getElementById('zeile_'+id);
	var zelle=share_zeile.firstChild;
	if(share_ids[id]==1){
		share_ids[id]=0;
		while(zelle!=null){
			if(zelle.nodeName=='TD')
				zelle.style.backgroundColor='';
			zelle=zelle.nextSibling;
		}
		document.getElementById('sharecheck_'+id).checked=false;
	}else{
		share_ids[id]=1;
		while(zelle!=null){
			if(zelle.nodeName=='TD')
				zelle.style.backgroundColor='"
				.$_SESSION['selected_td_color']."';
			zelle=zelle.nextSibling;
		}
		document.getElementById('sharecheck_'+id).checked=true;
	}
}

function changeshareprio(){
	var shareline='';
	var counter=-1;
	for (var i in share_ids){
		if(share_ids[i]==0) continue;
		counter++;
		shareline+='&sharefile['+counter+']=' + i;
	}
	window.location.href='index.php?site=sharefiles&dir=".urlencode($_GET['dir']) . "'+ shareline + '&sprio=' + document.shareprioform.shareprio.value + '&".SID."';
}

function reload(){
	window.location.href='index.php?site=sharefiles&dir=".urlencode($_GET['dir']) . "&forcereload=1&".SID."';
}

function exportlinks(){
	var shareexpline='';
	var counter=-1;
	
	for (var i in share_ids){
		if(share_ids[i]==0) continue;
		counter++;
		shareexpline+='&shareexpfile['+counter+']=' + i;
	}

	window.location.href='index.php?site=sharefiles&dir=".urlencode($_GET['dir']) . "'+ shareexpline+'&".SID."';
}

function selectall(){
	for(var v in share_ids){
		if(share_ids[v]==0) change(v);
	}
}
	
function selectnone(){
	for(var v in share_ids){
		if(share_ids[v]==1) change(v);
	}
}
</script>";
    
//prio setzen
if(!empty($_GET['sharefile'])){
	$Sharelist->setpriority($_GET['sharefile'],$_GET['sprio']);
}

if(!empty($_GET['forcereload'])){
	$Sharelist->refresh_cache(0);
}

//sharecache neu laden, falls aelter als 60min
$Sharelist->refresh_cache(60);

echo "<form name=\"shareprioform\" action=\"\">\n";
echo'<div class="card">
            <div class="card-body">
              <h5 class="card-title"><a href="index.php?site=shares"><i class="bi bi-arrow-left-circle"></i></a> '.htmlspecialchars($_GET["dir"]).'</h5>

              <!-- List group with Advanced Contents -->
 ';
echo '<nav aria-label="Page navigation">
                <ul class="pagination">
                  <li class="page-item">
                    <a class="page-link" onclick="exportlinks();">'.$lang["EXPORT"].'</a>
                  </li>
                  <li class="page-item"><a class="page-link" onclick="reload();">'.$lang['RELOAD'].'</a></li>
                  <li class="page-item"><a class="page-link" onclick="selectall();">'.$_SESSION['language']['GENERAL']['ALL'].'</a></li>
                  <li class="page-item"><a class="page-link" onclick="selectnone();">'.$_SESSION['language']['GENERAL']['NONE'].'</a></li>
                  
                </ul>
              </nav>
       <div class="list-group">   
';

//unterverzeichnisse
$dirliste=$Sharelist->directory($_GET['dir']);
foreach($dirliste as $a){
	
	echo ' <a href="index.php?site=sharefiles&dir='.rawurlencode($a[0]).'" data-html="true" class="list-group-item list-group-item-action" aria-current="true">
                  <div class="d-flex w-100 justify-content-between">
                    <p class="mb-1"><i class="bi bi-folder"></i> '.htmlspecialchars($a[1]).'</p>
                  <small></small>
                  </div>
                 </a>';
}

//dateien anzeigen
$items = $Sharelist->get_fileids($_GET['dir']);

$list = [];
foreach($items as $item) {
    $file = $Sharelist->get_file($item);
    $list[$file['SHORTFILENAME']] = $file;
}
unset($items);

ksort($list);

foreach($list as $shareentry){
    $a = $shareentry['ID'];
    if($shareentry["PRIORITY"] != "1"){
    
    $prio = "Prio: ".$shareentry['PRIORITY'];
    }else{
    }
    $lastasked=(isset($shareentry['LASTASKED'])) ?
		date("j.n.y - H:i:s",($shareentry['LASTASKED']/1000))
		: "N/A";
	if(!isset($shareentry['ASKCOUNT'])) $shareentry['ASKCOUNT']="N/A";
	if(!isset($shareentry['SEARCHCOUNT'])) $shareentry['SEARCHCOUNT']="N/A";
	
    $tooltip = "<small align='lef'>ID:".$a."<br>Letzte Anfrage: ".$lastasked."<br>Anzahl Anfragen: "
    			.$shareentry['ASKCOUNT']."<br>Anzahl Suchanfragen: ".$shareentry['SEARCHCOUNT']."<br>"
    			."<a href='".addslashes($shareentry['LINK'])."'>Scource Link</a></small>";
    
    	echo ' <a id="zeile_'.$a.'"  data-bs-toggle="tooltip" data-bs-placement="bottom" title="'.$tooltip.'" twipsy-content-set="true" data-bs-html="true" class="list-group-item list-group-item-action" aria-current="true">
                  <div class="d-flex w-100 justify-content-between">
                    <p class="mb-1">
                    <input type="checkbox" id="sharecheck_'.$a.'" onclick="change('.$a.')" />';
                    echo"<script>\n"
						."share_ids[$a]=0;\n"
						."</script>";
					echo' <i class="bi bi-file-earmark-play"></i> '.$shareentry["SHORTFILENAME"].'</p>
                  <small>'.sizeformat($shareentry["SIZE"]).'<br>'.$prio.'</small>
                  </div>
                 </a>';

    
	
}

echo "<tr><th colspan=\"$spaltenzahl\">";
echo $_SESSION['language']['GENERAL']['SELECT'].": ";
echo "<input type=\"button\" value=\""
	.$_SESSION['language']['GENERAL']['ALL']
	."\" onclick=\"selectall();\" /> ";
echo "<input type=\"button\" value=\""
	.$_SESSION['language']['GENERAL']['NONE']
	."\" onclick=\"selectnone();\" /></th></tr>";
echo "</div><!-- End List group Advanced Content -->

            </div>
          </div>";
echo "</form>";
echo strtr($lang['PRIO_SPENT'],array("%spent"=>$Sharelist->spentprio));

echo "</body>
</html>";
