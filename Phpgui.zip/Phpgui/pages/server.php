<?php
session_start();
require_once "_classes/subs.php";
require_once "_classes/server.php";

$Servers = new Server();
$lang =& $_SESSION['language']['SERVER'];
//zum connecten + loeschen
$action_echo='';
if(!empty($_GET['action'])){
	if(!empty($_GET['serv_id']) && $_GET['serv_id'] > 0)
		$action_echo = $Servers->action($_GET['action'], $_GET['serv_id']);
	//mehr server von applejuicenet.cc holen
	if($_GET['action']=='getservers'){
		$Servers->getmore();
	}
}

if($Servers->netstats['firewalled']==='true')
	echo 	"<span style=\"background-color:#FF0000;\"><img src=\"../style/"
		.$_SESSION['server_warning_icon']."\" />"
		.$lang['FIREWALLED']."</span><br />";
echo'<div class="row">';
$srv_timediff=$Servers->netstats['timeconnected']/60;

//server auflisten
foreach($Servers->ids() as $a){
	$serverinfo=$Servers->serverinfo($a);
	$server_delete_link="<a href=\"".$_SERVER['PHP_SELF']
		."?action=removeserver&amp;serv_id=".$serverinfo['ID']."&amp;"
		.SID."\">".$lang['DELETE']."</a>";

	if($Servers->netstats['connectedwith']<0 || $srv_timediff>=30){
		$server_connect_link="<a href=\"".$_SERVER['PHP_SELF']
			."&action=serverlogin&amp;serv_id="	.$serverinfo['ID']."&amp;"
			.SID."\">".$lang['LOGIN']."</a>";
	}else{
		$server_connect_link=$lang['LOGIN'];
	}
	//passendes bildchen raussuchen
	if($Servers->netstats['connectedwith'] == $serverinfo['ID']){
        $status = 'Verbunden <i class="bi bi-circle-fill text-success"></i>';
	}elseif($Servers->netstats['trytoconnectto'] == $serverinfo['ID']){
        $status = 'versuche zu verbinden <i class="bi bi-circle-fill text-danger"></i>';
	}elseif((($Servers->server_xml['TIME']['VALUES']['CDATA']
			-$serverinfo['LASTSEEN'])/1000) <= 86400){
        $status = '<24h verbunden gewesen <i class="bi bi-circle-fill text-warning"></i>';
	}else{
        $status = ' nicht verbunden <i class="bi bi-circle"></i>';
	}
    if(empty($serverinfo["NAME"])){
        $Json = file_get_contents("classes/server.json");
        // Converts to an array 
        $myarray = json_decode($Json, true);

            $namen = '';
        $namen_objekt = json_decode($namen);
        echo $namen_objekt->{'Fabian'}; 
    }
    echo'<div class="col-lg-4 col-md-12">
        <div class="card">
            <div class="card-header text-end">'.$status.'</div>
            <div class="card-body">
              <h5 class="card-title">'.htmlspecialchars($serverinfo["NAME"]).'</h5>
              <table>
              <tr>
              <td class="fw-bold">Server-URL</td>
              </tr>
              <tr>
              <td>'.$serverinfo["HOST"].'</td>
              </tr>
              <tr>
              <td class="fw-bold">Server-Port</td>
              </tr>
              <tr>
              <td>'.$serverinfo["PORT"].'</td>
              </tr>
              <tr>
              <td class="fw-bold">letzte Verbindung</td>
              </tr>
              <tr>
              <td>';echo ($serverinfo['LASTSEEN']>0) ?
        date("d.m.y - H:i:s",($serverinfo['LASTSEEN'])/1000) : "noch nicht verbunden"; echo'</td>
              </tr>
              </table>
            </div>
            <div class="card-footer text-end">
              '.$server_delete_link.'   '.$server_connect_link.' ('.$serverinfo["CONNECTIONTRY"].')
            </div>
          </div></div>';
}
echo "</div>\n";