<?php
$this->register("phpinfo","phpinfo/php.png","phpinfo/phpinfo.php");
