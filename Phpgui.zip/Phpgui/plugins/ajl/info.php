<?php
$this->register("Link Import","ajl/icon.gif","ajl/ajl.php");	// pfadangaben hier relativ zum plugins verzeichnis
