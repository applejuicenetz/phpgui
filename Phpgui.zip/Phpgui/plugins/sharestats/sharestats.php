<?php
require_once "_classes/core.php";
$core = new Core;
/*
sharestats
*/
require_once "_classes/share.php";

?>
<div class="card">
<?php
echo "<a href=\"index.php?site=extras&show=sharestats/sharestats.php&amp;stats=last\">"
	."K&uuml;rzlich angefordert</a>";
echo "<a href=\"index.php?site=extras&show=sharestats/sharestats.php&amp;stats=most\">"
	."H&auml;ufig angefragt</a>";
echo "<a href=\"index.php?site=extras&show=sharestats/sharestats.php&amp;stats=search\">"
	."Am misten gesucht</a>";
$coreinfo=$core->getcoreversion();
$coresubversions=explode(".",$coreinfo['VERSION']);
if($coresubversions[2]<146) die("<img src=\"../style/"
	.$_SESSION['server_warning_icon']."\" alt=\"[!]\" />"
	."Core 0.30.146.1203 or newer required");
if(empty($_GET['stats'])) $_GET['stats']="most";
$Sharelist = new Share;
$Sharelist->refresh_cache(2);
if(!empty($Sharelist->cache['SHARES']['VALUES']['SHARE'])){
	echo "<div style=\"float:left; margin-left:1cm;\">";
	echo "<table>";
	echo "<tr>";
	echo "<th>Position</th>";
	$sfsort=array();
	switch($_GET['stats']){
		case "most":
			echo "<th>Requests</th>";
			$sfsort=ajsort($Sharelist->cache['SHARES']
				['VALUES']['SHARE'],'ASKCOUNT',SORT_NUMERIC,1);
			$statsvalue='ASKCOUNT';
			break;
		case "-most":
			echo "<th>Requests</th>";
			$sfsort=ajsort($Sharelist->cache['SHARES']
				['VALUES']['SHARE'],'ASKCOUNT',SORT_NUMERIC,0);
			$statsvalue='ASKCOUNT';
			break;
		case "search":
			echo "<th>Search Requests</th>";
			$sfsort=ajsort($Sharelist->cache['SHARES']
				['VALUES']['SHARE'],'SEARCHCOUNT',SORT_NUMERIC,1);
			$statsvalue='SEARCHCOUNT';
			break;
		case "-search":
			echo "<th>Search Requests</th>";
			$sfsort=ajsort($Sharelist->cache['SHARES']
				['VALUES']['SHARE'],'SEARCHCOUNT',SORT_NUMERIC,0);
			$statsvalue='SEARCHCOUNT';
			break;
		case "-last":
			echo "<th>Date</th>";
			$sfsort=ajsort($Sharelist->cache['SHARES']
				['VALUES']['SHARE'],'LASTASKED',SORT_NUMERIC,0);
			$statsvalue='LASTASKED';
			break;
		default:
			echo "<th>Date</th>";
			$sfsort=ajsort($Sharelist->cache['SHARES']
				['VALUES']['SHARE'],'LASTASKED',SORT_NUMERIC,1);
			$statsvalue='LASTASKED';
			break;
	}
	$sfsort=array_keys($sfsort);
	echo "<th>Filename</th></tr>";
	for($i=0;$i<30;$i++){
		if(!empty($sfsort[$i])){
			$cur_share=&$Sharelist->get_file($sfsort[$i]);
			echo "<tr><td style=\"font-weight:bold; text-align:center;\">"
				.($i+1).".</td><td style=\"text-align:center;\">";
			$wert=$cur_share[$statsvalue];
			echo ($statsvalue=='LASTASKED') ?
				date("j.n.y - H:i:s",($wert/1000)) : $wert;
			echo "</td><td>";
			echo "<a href=\"ajfsp://file|"
				.$cur_share['SHORTFILENAME']."|"
				.$cur_share['CHECKSUM']."|"
				.$cur_share['SIZE']."/\">";
			echo htmlspecialchars($cur_share['SHORTFILENAME']);
			echo "</a></td></tr>";
		}
	}
	echo "</table>";
	echo "</div></div></div>";
}
