<?php
$this->register("Share Stats","","sharestats/sharestats.php");	// pfadangaben hier relativ zum plugins verzeichnis
