<?php
session_start();
require_once "subs.php";
require_once "classes/class_search.php";
$Search = new Search();
$lang =& $_SESSION['language']['SEARCH'];

if(empty($_GET['searchid'])) $_GET['searchid']="alles";
echo "<meta http-equiv=\"refresh\" content=\""
	.$_ENV['GUI_REFRESH_SEARCH']."; URL=".$_SERVER['PHP_SELF']."?searchid="
	.$_GET['searchid']."&amp;".SID."\" />";    //neu laden

echo "<script type=\"text/javascript\">
<!--
function dllink(ajfsplink){
	parent.oben.document.linkform.ajfsp_link.value=ajfsplink;
	parent.oben.document.linkform.showlinkpage.value=0;
	parent.oben.document.linkform.submit();
}

function toggleinfo(id,items){
	var infobox=document.getElementById('infobox_'+id);
	if(infobox.style.display=='block'){
		infobox.style.display='none';
	}else{
		if(infobox.firstChild==null){
			var zeilen=items.split('|');
			var linkinfo=zeilen.pop().split('/');
			infobox.appendChild(document.createTextNode('"
				.addslashes($lang['KNOWN_FILENAMES'])
				.":'));
			infobox.appendChild(document.createElement('br'));
			while(zeilen.length>0){
				var nameinfo=zeilen.shift().split('/');
				infobox.appendChild(
					document.createTextNode('['+nameinfo[0]+'x] '));
				var ajlink=document.createElement('a');
				ajlink.setAttribute('href',
					\"javascript:dllink('ajfsp://file|\"
					+nameinfo[1].replace(/\'/g,\"\\\\'\")+\"|\"
					+linkinfo.join('|')+\"/\\')\");
				ajlink.appendChild(document.createTextNode(nameinfo[1]));
				infobox.appendChild(ajlink);
				infobox.appendChild(document.createElement('br'));
			}
		}
		infobox.style.display='block';
	}
}
//-->
</script>";

$action_echo='';
//suchanfrage an core uebergeben
if(!empty($_POST['searchstring'])){
	$_POST['searchstring']=trim($_POST['searchstring']);
	$Search->start($_POST['searchstring']);
}

//suche abbrechen
if(!empty($_GET['cancelid'])){
	$Search->cancel($_GET['cancelid']);
}

$Search->refresh_cache();

//suche loeschen
if(!empty($_GET['deleteid'])){
	$action_echo .= $Search->delete($_GET['deleteid']);
}

//alle ergebnisse loeschen
if(!empty($_GET['deleteall'])){
	$action_echo .= $Search->delete_all();
}

echo "<tr><td colspan=\"4\">\n";
echo "<span";
if($_GET['searchid']==="alles"){
	echo " class='search_selected'>";
}else{
	echo " class='search'>";
}

$Search->process_results();
echo'<div class="card">
            <div class="card-body">
              <h5 class="card-title">'; 
              echo "<form action=\"".$_SERVER['PHP_SELF']."?site=search".SID."\" method=\"post\">";
echo "<input size=\"60 name=\"searchstring\" /> ";
echo '<button type="submit" class="btn btn-primary"><i class="b bi-search"></i></button>';
echo "</form>\n";
echo'</h5>
              <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item" role="presentation">
                  <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#alles" type="button" role="tab" aria-controls="home" aria-selected="true">
                  '.$lang['ALL_RESULTS'].'('.$Search->cache['SEARCHENTRY_count'].')
                  <a href="'.$_SERVER['PHP_SELF'].'?site=search&deleteall=1&'.SID.'"><span class="badge bg-danger"><i class="bi bi-x-square-fill"></i></span></a>
                  </button>
                </li>
               ';

//link fuer alle ergebnisse
//echo "<a href=\"".$_SERVER['PHP_SELF']."?searchid=alles&amp;".SID."\">"
//	.$lang['ALL_RESULTS']."("
//	.$Search->cache['SEARCHENTRY_count']
//	.")</a><a href=\"".$_SERVER['PHP_SELF']."?site=search&deleteall=1&amp;"
//	.SID."\" title=\"Delete all\">"
//	."<img border=\"0\" src=\"../style/".$_SESSION['search_delete_icon']
//	."\" alt='delete' /></a></span>\n";
echo ' <li class="nav-item" role="presentation">
                  <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">Profile</button>
                </li>
                <li class="nav-item" role="presentation">
                  <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact" type="button" role="tab" aria-controls="contact" aria-selected="false">Contact</button>
                </li>
              
              ';
if(!empty($Search->cache['SEARCH'])){
	//links fuer die einzelnen suchen
	foreach(array_keys($Search->cache['SEARCH']) as $b){
	//name der suche + zahl der ergebnisse
	echo'<li class="nav-item" role="presentation">
                  <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#'.$b.'" type="button" role="tab" aria-controls="profile" aria-selected="false">
                  '.$Search->cache["SEARCH"][$b]["SEARCHTEXT"].'('.$Search->cache["SEARCH"][$b]["phpaj_FOUNDFILES"].')
                  <a href="'.$_SERVER['PHP_SELF'].'?site=search&cancleid='.$b.'"><span class="badge bg-danger"><i class="bi bi-x-square-fill"></i></span></a>
                  
                  </button>
                </li>
       ';
		echo "<a href=\"".$_SERVER['PHP_SELF']."?searchid=".$b."&amp;".SID."\">"
			.$Search->cache['SEARCH'][$b]['SEARCHTEXT']
			."(".$Search->cache['SEARCH'][$b]['phpaj_FOUNDFILES']
			.")</a>";
		//icon zum abbrechen/loeschen der suche
		if($Search->cache['SEARCH'][$b]['RUNNING']==="true"){
			echo "<a href=\"".$_SERVER['PHP_SELF']."?cancelid=".$b
				."&amp;".SID."\" title=\"Cancel search\">"
				."<img border=\"0\" src=\"../style/"
				.$_SESSION['search_cancel_icon']."\" alt='cancel' /></a>";
		}else{
			echo "<a href=\"".$_SERVER['PHP_SELF']."?deleteid=".$b
				."&amp;".SID."\" title=\"Delete search\">"
				."<img border=\"0\" src=\"../style/"
				.$_SESSION['search_delete_icon']."\" alt='delete' /></a>";
		}
		echo "</span>\n";
		echo "&nbsp;";
	}
}
echo '</ul>
<div class="tab-content pt-2" id="myTabContent">
     ';

if($_GET['searchid']!=="alles"){
	$current_search=&$Search->cache['SEARCH'][$_GET['searchid']];
	if(($current_search['SUMSEARCHES']+$current_search['OPENSEARCHES'])>0){
		$current_search_percent=(($current_search['SUMSEARCHES']*100)/
			($current_search['SUMSEARCHES']+$current_search['OPENSEARCHES']));
	
	    echo'<div class="tab-pane fade show active" id="alles" role="tabpanel" aria-labelledby="home-tab">
            	<div class="progress mt-3">
                	<div class="progress-bar progress-bar-striped bg-success progress-bar-animated" role="progressbar" style="width: '.round($current_search_percent,0).'%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
                		'.number_format($current_search_percent,2).' % ('.$current_search['SUMSEARCHES'].'/'.($current_search['SUMSEARCHES']+$current_search['OPENSEARCHES']).'
			.")
                	</div>
            	</div>
              
             </div>';
    	}
	echo "";
}

//Sortieren
if(!empty($Search->cache['SEARCHENTRY'])){
if(empty($_GET['sort'])) $_GET['sort']="count";
$searchsort=$Search->sortieren($_GET['sort']);
}

//tabellenueberschriften
echo "<tr>
<th><a href=\"".$_SERVER['PHP_SELF']."?sort=name&amp;searchid=".$_GET['searchid']
	."&amp;".SID."\">"
	.$lang['NAME']."</a></th>";

if(!empty($_ENV['REL_INFO'])) {
    echo '<th width="16" align="center"><img src="../style/default/info.png" width="16" alt="" /></th>';
}

echo "<th><a href=\"".$_SERVER['PHP_SELF']."?sort=size&amp;searchid="
	.$_GET['searchid']."&amp;".SID."\">"
	.$lang['SIZE']."</a></th>
<th><a href=\"".$_SERVER['PHP_SELF']."?sort=count&amp;searchid=".$_GET['searchid']
	."&amp;".SID."\">"
	.$lang['COUNT']."</a></th>
<th>&nbsp;</th></tr>";

//suchergebnisse anzeigen
if(!empty($Search->cache['SEARCHENTRY'])){
	$result_counter=500;
	foreach(array_keys($searchsort) as $a ){
		$cur_search =& $Search->cache['SEARCHENTRY'][$a];
		//pruefen, ob ergebnis zu suche geh�rt
		if($_GET['searchid']!=="alles"
			&& $cur_search['SEARCHID']!==$_GET['searchid']) continue;
		$result_counter--;
		if($result_counter<0 && empty($_GET['nolimit'])){
			//nach 500 ergebnissen den rest weglassen, wenn nicht anders gewuenscht
			echo "<tr><th colspan=\"4\"><a href=\"".$_SERVER['PHP_SELF']."?searchid="
				.$_GET['searchid']."&amp;nolimit=1&amp;".SID."\">"
				.$lang['NO_LIMIT']."</a></th></tr>";
			break;
		}
		//anzeige aller namen + anzahl
		$sort_names=array();
			foreach(array_keys($cur_search['FILENAME']) as $b){
				$sort_names["$b"]=$cur_search['FILENAME'][$b]['USER'];
			}
		arsort($sort_names,SORT_NUMERIC);
		$names=array_keys($sort_names);
		echo "<tr><td>\n<a href=\"javascript:toggleinfo($a,'";
		foreach($names as $c){
			echo $sort_names["$c"]."/".addslashes(htmlspecialchars($c))."|";
		}
		echo $cur_search['CHECKSUM']."/".$cur_search['SIZE'];
		echo "')\"><img border=\"0\" src=\"../style/"
			.$_SESSION['search_info_icon']."\" alt='info' /></a>\n";
		//download starten
		$ajfsp_link="ajfsp://file|".addslashes(htmlspecialchars($names[0]))."|"
			.$cur_search['CHECKSUM']."|".$cur_search['SIZE']."/";
		echo "<a href=\"javascript:dllink('".$ajfsp_link
			."');\" title=\"Download\">\n".htmlspecialchars($names[0])."</a>";
		echo "<br /><div id=\"infobox_$a\" class=\"infobox\"></div></td>\n";
		//dateigröße

        if (!empty($_ENV['REL_INFO'])) {
            echo '<td align="center"><a target="_blank" href="' . sprintf($_ENV['REL_INFO'], $ajfsp_link) . '"><img src="../style/default/info.png" width="16" alt="" border="0" title="Information" /></a></td>';
        }

		echo "<td class=\"right\">"
			.sizeformat($cur_search['SIZE'])
			."</td>\n";
		//anzahl der ergebnisse
		echo "<td class=\"right\">"
			.$cur_search['phpaj_COUNT']
			."\n</td>";
		//ajfsp-link zu datei
		echo "<td><a href=\"".$ajfsp_link."\">ajfsp-link</a></td></tr>\n\n";
	}
}

echo "</table>";
echo $action_echo;
echo "</body>
</html>";

echo'           <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                  Nesciunt totam et. Consequuntur magnam aliquid eos nulla dolor iure eos quia. Accusantium distinctio omnis et atque fugiat. Itaque doloremque aliquid sint quasi quia distinctio similique. Voluptate nihil recusandae mollitia dolores. Ut laboriosam voluptatum dicta.
                </div>
                <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                  Saepe animi et soluta ad odit soluta sunt. Nihil quos omnis animi debitis cumque. Accusantium quibusdam perspiciatis qui qui omnis magnam. Officiis accusamus impedit molestias nostrum veniam. Qui amet ipsum iure. Dignissimos fuga tempore dolor.
                </div>
              </div><!-- End Default Tabs -->
</div>
          </div>
          ';
