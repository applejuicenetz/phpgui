<?php
header('Cache-Control: no-cache');
header('Content-Type: text/html; charset=UTF-8');

session_start();

require_once 'subs.php';
require_once 'login.php';
require_once "classes/class_core.php";
require_once "classes/class_extra.php";
require_once "../plugins/register.php";

$Plugin =new Plugin();
$Plugin->Find_Plugins();
$core = new Core();

$settings_xml=$core->command("xml","settings.xml");

if (empty($_SESSION['core_host'])) {
 ?>
 <script type="text/javascript">
<!--
window.location = "../index.php";
//�>
</script>
<?php }

$tabs = ['start', 'downloads', 'uploads', 'shares', 'search', 'server', 'settings', 'extras'];


$tab = 'Start';
if($_GET["site"] == "sharefiles" OR $_GET["site"] == "shareexport") $tab = "Shares";
function active($a){
    if($a != $_GET["site"]){
        $action = "collapsed";
        echo $action;
    }else{

    }
}
function activee($a){
    if($a != $_GET["site"]){
        $action = "collapse";
        echo $action;
    }else{

    }
}
if (isset($_GET['site']) && in_array($_GET['site'], $tabs, true)) {
    $tab = ucfirst($_GET['site']);
    $active ='';
}else{
    $active ='collapsed';
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title><?php echo $tab; ?> - AppleJuice </title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="/gui/themen/NiceAdmin/assets/img/favicon.ico" rel="icon">
  <link href="/gui/themen/NiceAdmin/assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="/gui/themen/NiceAdmin/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="/gui/themen/NiceAdmin/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="/gui/themen/NiceAdmin/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="/gui/themen/NiceAdmin/assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="/gui/themen/NiceAdmin/assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="/gui/themen/NiceAdmin/assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="/gui/themen/NiceAdmin/assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="/gui/themen/NiceAdmin/assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: NiceAdmin
  * Updated: Jan 29 2024 with Bootstrap v5.3.2
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

    <div class="d-flex align-items-center justify-content-between">
      <a href="index.php?page=start" class="logo d-flex align-items-center">
        <img src="assets/img/logo.png" alt="">
        <span class="d-none d-lg-block">AppleJuice PHPGui</span>
      </a>
      <i class="bi bi-list toggle-sidebar-btn"></i>
    </div><!-- End Logo -->

    <div class="search-bar">
        <?php echo'
<form method="post" action="'.$_SERVER["PHP_SELF"].'" name="linkform" class="search-form d-flex align-items-center">
<input name="showlinkpage" type="hidden" value="1" />
<input name="'.session_name().'" type="hidden" value="'.session_id().'" />
        <input type="text" id="link"  name="ajfsp_link" placeholder="Link einfuegen" title="Enter search keyword">
        <button type="submit" title="Search"><i class="bi bi-search"></i></button>
      </form>'; ?>
    </div><!-- End Search Bar -->

    <nav class="header-nav ms-auto">
      <ul class="d-flex align-items-center">

        <li class="nav-item d-block d-lg-block">
          <a class="nav-link nav-icon search-bar-toggle " href="#">
            <i class="bi bi-search"></i>
          </a>
        </li>
<!-- End Search Icon -->

        <li class="nav-item dropdown pe-3">

          <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
            <img src="../themen/NiceAdmin/assets/img/user-avatar.png" alt="Profile" class="rounded-circle">
            <span class="d-none d-md-block dropdown-toggle ps-2"><?php echo $settings_xml['NICK']['VALUES']['CDATA']; ?></span>
          </a>

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
            <li class="dropdown-header">
              <h6><?php echo $settings_xml['NICK']['VALUES']['CDATA']; ?></h6>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="index.php?site=kickcore">
                <i class="ri-shut-down-line"></i>
                <span>Core beenden</span>
              </a>
            </li>
<li>
              <a class="dropdown-item d-flex align-items-center" href="index.php?site=settings">
                <i class="ri-settings-4-line"></i>
                <span>Einstellungen</span>
              </a>
            </li>
<li>
              <a class="dropdown-item d-flex align-items-center" href="index.php?site=logout">
                <i class="bi bi-box-arrow-right"></i>
                <span>Logout</span>
              </a>
            </li>
          </ul>
        </li>

      </ul>
    </nav><!-- End Icons Navigation -->

  </header><!-- End Header -->
    <!-- ======= Sidebar ======= -->
    <aside id="sidebar" class="sidebar">

        <ul class="sidebar-nav" id="sidebar-nav">

            <li class="nav-item">
                <a class="nav-link <?php active("start"); ?>" href="index.php?site=start">
                    <i class="bi bi-grid"></i>
                    <span>Dashboard</span>
                </a>
            </li><!-- End Dashboard Nav -->
            <li class="nav-item">
                <a class="nav-link <?php active("downloads"); ?>" href="index.php?site=downloads">
                    <i class="bi bi-download"></i>
                    <span>Downloads</span>
                </a>
            </li><!-- End Dashboard Nav -->
            <li class="nav-item">
                <a class="nav-link <?php active("uploads"); ?>" href="index.php?site=uploads">
                    <i class="bi bi-upload"></i>
                    <span>Uploads</span>
                </a>
            </li><!-- End Dashboard Nav -->
            <li class="nav-item">
                <a class="nav-link <?php active("search"); ?>" href="index.php?site=search">
                    <i class="bi bi-search"></i>
                    <span>Suche</span>
                </a>
            </li><!-- End Dashboard Nav -->
            <li class="nav-item">
                <a class="nav-link <?php active("shares"); ?>" href="index.php?site=shares">
                    <i class="bi bi-folder-symlink"></i>
                    <span>geteilte Ortner</span>
                </a>
            </li><!-- End Dashboard Nav -->
            <li class="nav-item">
                <a class="nav-link <?php active("server"); ?>" href="index.php?site=server">
                    <i class="bi bi-server"></i>
                    <span>Serverliste</span>
                </a>
            </li><!-- End Dashboard Nav -->
            <li class="nav-item">
                <a class="nav-link <?php active("settings"); ?>" href="index.php?site=settings">
                    <i class="bi bi-gear"></i>
                    <span>Einstellungen</span>
                </a>
            </li><!-- End Dashboard Nav -->
            
                    <li class="nav-item">
                        <a class="nav-link <?php active("extras"); ?>" data-bs-toggle="collapse" data-bs-target="#forms-nav" href="#">
                            <i class="bi bi-ui-checks-grid"></i>
                            <span>Addons</span><i class="bi bi-chevron-down ms-auto"></i>
                </a>
                        <ul id="forms-nav" class="nav-content <?php activee("extras"); ?>" data-bs-parent="#sidebar-nav">
                    <?php
                    $phpaj_pluginurllist=array();

                    // Links zu den plugins zeigen

                    foreach($Plugin->liste as $a){
                        echo '                    <li>
                        <a href="index.php?site=extras&show='.$a[2].'">
                            <i class="bi bi-circle"></i><span>'.$a[0].'</span>
                        </a>
                    </li>';
                    }

                    ?>


                </ul>
            </li><!-- End Forms Nav -->

        </ul>

    </aside><!-- End Sidebar-->


  <main id="main" class="main">
<!-- Search Ausgabe -->
<?php 
if (!empty($_SESSION['ajfsp_link']) && empty($_REQUEST['ajfsp_link'])) {
    $_REQUEST['ajfsp_link'] = $_SESSION['ajfsp_link'];
    $_REQUEST['showlinkpage'] = 1;
    unset($_SESSION['ajfsp_link']);
}

if (!empty($_REQUEST['ajfsp_link'])) {

    $regexe = [
        // ajfsp://file|ajcore-0.31.149.110.jar|653f4d793595e65bbbe58c0c55620589|313164/
        '#ajfsp://(file)\|([^|]*)\|([a-z0-9]{32})\|([\d]*)/#',

        // ajfsp://server|knastbruder.applejuicenet.de|9855/
        '#ajfsp://(server)\|([^|]*)\|([\d]{1,5})/#',

        // ajfsp://file|ajcore-0.31.149.110.so|653f4d793595e65bbbe58c0c55620589|313164|123.123.123.123:9850/
        '#ajfsp://(file)\|([^|]*)\|([a-z0-9]{32})\|([\d]*)\|[\d]{1,3}\.[\d]{1,3}\.[\d]{1,3}\.[\d]{1,3}:[\d]{1,5}/#',

        // ajfsp://file|ajcore-0.31.149.110.jar|653f4d793595e65bbbe58c0c55620589|313164|123.123.123.123:9850:knastbruder.applejuicenet.de:9855/
        '#ajfsp://(file)\|([^|]*)\|([a-z0-9]{32})\|([\d]*)\|[\d]{1,3}\.[\d]{1,3}\.[\d]{1,3}\.[\d]{1,3}:[\d]{1,5}:[^:]*:[\d]{1,5}/#',
    ];

    $links = [];

    foreach ($regexe as $regex) {
        preg_match_all($regex, urldecode($_REQUEST['ajfsp_link']), $matches, PREG_SET_ORDER);
        $links = array_merge($links, $matches);
    }

    echo'<div class="alert alert-info alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-octagon me-1"></i>
';
    foreach ($links as $link) {

        //Infos fr Dateilink anzeigen + im hauptfenster die downloads zeigen
        if ('file' === $link[1]) {
            echo htmlspecialchars($link[2]) . ' (' . sizeformat($link[4]) . ') &rArr; ';
            echo $core->command('function', 'processlink?link=' . urlencode($link[0])) . ' &middot; ';

            if (!empty($_REQUEST['showlinkpage'])) {
                echo "<script>parent.main.location.href='?site=downloads';</script>";
            }
        }
        //Infos f�r Serverlink anzeigen + im hauptfenster die server zeigen
        if ('server' === $link[1]) {
            echo htmlspecialchars($link[2]) . ':' . htmlspecialchars($link[3]) . ' &rArr; ';
            echo $core->command('function', 'processlink?link=' . urlencode($link[0]));
            if (!empty($_REQUEST['showlinkpage'])) {
                echo "<script>parent.main.location.href='server.php';</script>";
            }
        }


    }
    echo '
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>';
}
$currentUrl = sprintf(
    '%s://%s%s',
    isset($_SERVER['HTTPS']) ? 'https' : 'http',
    $_SERVER['HTTP_HOST'],
    str_replace('top.php', 'index.php', $_SERVER['REQUEST_URI'])
);

$permaLink = sprintf('%s|%s', $_SESSION['core_host'], $_SESSION['core_pass']);

?>
<div class="pagetitle">
      <h1><?php echo $tab; ?></h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php?site=start">Home</a></li>
            <li class="breadcrumb-item"><?php echo $tab; ?></li>

            <?php bread($_GET["show"]); ?>


        </ol>
      </nav>
    </div><!-- End Page Title -->

<?php if(!isset($_GET['site'])){
include("start.php");
}else{
include($_GET['site'].".php");
}
?>
</main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>NiceAdmin</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
      <!-- All the links in the footer should remain intact. -->
      <!-- You can delete the links only if you purchased the pro version. -->
      <!-- Licensing information: https://bootstrapmade.com/license/ -->
      <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/ -->
      Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="/gui/themen/NiceAdmin/assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="/gui/themen/NiceAdmin/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="/gui/themen/NiceAdmin/assets/vendor/chart.js/chart.umd.js"></script>
  <script src="/gui/themen/NiceAdmin/assets/vendor/echarts/echarts.min.js"></script>
  <script src="/gui/themen/NiceAdmin/assets/vendor/quill/quill.min.js"></script>
  <script src="/gui/themen/NiceAdmin/assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="/gui/themen/NiceAdmin/assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="/gui/themen/NiceAdmin/assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="/gui/themen/NiceAdmin/assets/js/main.js"></script>

</body>

</html>
