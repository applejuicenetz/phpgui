<?php
include("_includes/header.php");

$template = new template();
if(!isset($_GET["show"])) $_GET["show"] = "";
if(empty($_GET["site"])) $_GET["site"] = "start";
echo'<div class="pagetitle">
      <h1>'.$tab.'</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php?site=start">Home</a></li>
            <li class="breadcrumb-item">'.$tab.'</li>

            '.$template->bread($_GET["show"]).'


        </ol>
      </nav>
    </div>';
if(file_exists("pages/".$_GET['site'].".php")){

include_once("pages/".$_GET['site'].".php");

}else{
   
include_once("pages/404.php");

}

include("_includes/footer.php");
?>