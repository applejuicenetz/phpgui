<?php
class template{
	function bread($a){
		if(empty($a)){echo "";
		}else{
			$sub = substr($a, 0, strpos($a, '/'));
    		return '<li class="breadcrumb-item active">'.ucfirst($sub).'</li>';
		}
	}
	function bread2($a){
        $tab = ucfirst($a);
        foreach($_GET as $key => $value){
         	$sub = substr($_GET["$key"], 0, strpos($_GET["$key"], '/'));
            return '<li class="breadcrumb-item active">'.ucfirst($sub).'</li>';
        }
	}

}