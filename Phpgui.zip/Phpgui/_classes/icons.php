<?php
class Icons{
	var $os;
	var $serverstatus;
	var $directstate;
	
	function __construct(){
		//Passendes symbol (oder name) fuer betriebssystem der id zuordnen
		$this->os = array(
			"0" => "<i class='bi bi-question-circle'></i>",
			"1" => "<img src='https://cdn-icons-png.freepik.com/512/888/888882.png' width='20px' height='20px'>",
			"2" => "<img src='https://cdn-icons-png.freepik.com/512/6124/6124995.png' width='20px' height='20px'>",
			"3" => "<i class='bi bi-apple'></i>",
			"4" => "solaris",
			"5" => "os2",
			"6" => "bsd",
			"7" => "netware");
}

}
